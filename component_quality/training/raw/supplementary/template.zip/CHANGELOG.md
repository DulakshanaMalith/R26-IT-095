# Changelog

This template builds on the *Corporate Design LaTeX Templates for TU Darmstadt* v3.41 (2024-07-02) by Marei Peischl (2018–2024), licensed under the LaTeX Project Public License (LPPL-1.3c). See: https://github.com/tudace/tuda_latex_templates

## 2024-11-11

### .tex
- **Expanded instructional chapters (based on “Einführung in das wissenschaftliche Arbeiten”, WiSe 2024/25, TU Darmstadt):**
  - **Motivation**: guidance on crafting a hook, establishing context (anchor), formulating a teaser, and deriving clear research questions.
  - **Approach**: instructions for literature review (state of the art/related work), presenting theoretical foundations, and detailing the methodology.
  - **Schedule**: example and template for proposing a realistic thesis timeline.

### .cfg
- **Title page fields:** added inputs for responsible staff (e.g., supervisor/chair) and matriculation number.
- **Anonymisation toggle:** option to hide personal details for pdf creation.
